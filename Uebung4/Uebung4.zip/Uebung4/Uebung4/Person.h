#pragma once
#include <string>
using namespace std;

// Abstract Class all member functions are virtual
class Person
{
public:
	Person();
	virtual ~Person();
	Person(string vorname, string nachname);
	virtual void setVorname(string vorname);
	virtual void setNachname(string nachname);
	virtual const string& getNachname();
	virtual const string& getVorname();
	// Member function = 0 child class can override this function
	virtual string toString() = 0;
private:
	string nachname;
	string vorname;
};

