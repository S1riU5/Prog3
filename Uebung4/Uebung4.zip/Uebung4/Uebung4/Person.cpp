#include "Person.h"
#include <iostream>

/// <summary>
/// Constructor initialize the class atributes
/// </summary>
/// <param name="vorname"></param>
/// <param name="nachname"></param>
Person::Person(string vorname, string nachname)
{
	this->vorname = vorname;
	this->nachname = nachname;
}
/// <summary>
/// Default Constructor
/// </summary>
Person::Person()
{
}


/// <summary>
/// return the nachname attributte
/// </summary>
/// <returns></returns>
const string& Person::getNachname()
{
	return nachname;
}

/// <summary>
/// return the  vorname attribute
/// </summary>
/// <returns></returns>
const string& Person::getVorname()
{
	return vorname;
}


/// <summary>
/// return a string of all class attributes (name, nachname)
/// </summary>
/// <returns></returns>
string Person::toString()
{
	return vorname.append(" ").append(nachname);
}

/// <summary>
///  Set the value given to the parameter list as the attribute vorname
/// </summary>
/// <param name="vorname"></param>
void Person::setVorname(string vorname)
{
	this->vorname = vorname;
}

/// <summary>
/// set the value  given in the parameterlist as the attribute nachname
/// </summary>

void Person::setNachname(string nachname)
{
	this->nachname = nachname;
}

/// <summary>
/// Destructor
/// </summary>

Person::~Person()
{
}
