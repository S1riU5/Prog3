#include "StudentIN.h"


StudentIN::StudentIN(string vorname, string nachename, string matrikelnummer)
{
	//Person(vorname, nachename);
	setVorname(vorname);
	setNachname(nachename);
	this->matrikelnummer = matrikelnummer;
}


string StudentIN::toString()
{
	return string("StudentIn ").append(getVorname()).append(" ").append(getNachname()).append(" Matrikelnummer: ").append(matrikelnummer);
}


string StudentIN::getMatrikelnummer()
{
	return matrikelnummer;
}


StudentIN::~StudentIN()
{
}

